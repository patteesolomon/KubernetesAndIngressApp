package org.example.project

const val SERVER_PORT = 8080